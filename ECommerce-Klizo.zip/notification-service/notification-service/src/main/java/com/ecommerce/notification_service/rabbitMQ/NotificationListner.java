package com.ecommerce.notification_service.rabbitMQ;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.ecommerce.notification_service.config.RabbitMQConfig;
import com.ecommerce.notification_service.dto.Notification;
import com.ecommerce.notification_service.service.MailService;


@Service
public class NotificationListner {

	private final MailService mailService;
	
	public NotificationListner(MailService mailService) {
		this.mailService = mailService;
	}
	
	@RabbitListener(queues = RabbitMQConfig.ORDER_NOTIFICATION_QUEUE)
    public void receiveOrderMessage(@Payload Notification notification) {
		
        if(notification.getStatus().equals("PAID")) {
        	mailService.sendSimpleEmail(notification.getUsermail(),"Order Notification","Successful placed order for Order ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        	System.out.println("Customer mail "+ notification.getUsermail());
        	System.out.println("Successful placed order for Order ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        }
        else if(notification.getStatus().equals("FAILED")) {
        	mailService.sendSimpleEmail(notification.getUsermail(),"Order Notification","Failed to placed order for Order ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        	System.out.println("Customer mail "+ notification.getUsermail());
        	System.out.println("Failed to placed order for Order ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        }
        else if(notification.getStatus().equals("CANCELLED")) {
        	mailService.sendSimpleEmail(notification.getUsermail(),"Order Notification","Canceled order for Order ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        	System.out.println("Customer mail "+ notification.getUsermail());
        	System.out.println("Canceled order for Order ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        }
    }
	
	
	@RabbitListener(queues = RabbitMQConfig.PAYMENT_NOTIFICATION_QUEUE)
    public void receivePaymentMessage(@Payload Notification notification) {
        if(notification.getStatus().equals("PAID")) {
        	mailService.sendSimpleEmail(notification.getUsermail(),"Payment Notification","Successful completed payment for Payment id : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        	System.out.println("Customer mail "+ notification.getUsermail());
        	System.out.println("Successful completed payment for Payment id : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        }
        else if(notification.getStatus().equals("PENDING")) {
        	mailService.sendSimpleEmail(notification.getUsermail(),"Payment Notification","Please complete the payment fot the payment id : "+notification.getOrderId()+" for payment amount : "+notification.getAmount());
        	System.out.println("Customer mail "+ notification.getUsermail());
        	System.out.println("Please complete the payment fot the payment id : "+notification.getOrderId()+" for payment amount : "+notification.getAmount());
        }
        else if(notification.getStatus().equals("CANCELLED") || notification.getStatus().equals("REFUNDED")) {
        	mailService.sendSimpleEmail(notification.getUsermail(),"Payment Notification",notification.getStatus()+" payment for payment ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        	System.out.println("Customer mail "+ notification.getUsermail());
        	System.out.println(notification.getStatus()+" payment for payment ID : "+notification.getOrderId()+" with payment amount : "+notification.getAmount());
        }
    }
}
