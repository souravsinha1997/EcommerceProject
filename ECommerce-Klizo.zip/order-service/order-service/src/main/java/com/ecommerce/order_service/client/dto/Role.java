package com.ecommerce.order_service.client.dto;

public enum Role {
	ADMIN, USER
}
