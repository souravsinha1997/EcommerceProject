package com.ecommerce.customer_service.entity;

public class Token {

	private String token;
	
	public Token(String token) {
		this.token=token;
	}
	
	public String getToken() {
		return token;
	}
}
