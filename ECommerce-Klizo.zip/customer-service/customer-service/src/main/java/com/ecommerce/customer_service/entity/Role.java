package com.ecommerce.customer_service.entity;

public enum Role {
	ADMIN, USER
}
