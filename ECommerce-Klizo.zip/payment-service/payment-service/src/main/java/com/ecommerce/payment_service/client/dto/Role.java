package com.ecommerce.payment_service.client.dto;

public enum Role {
	ADMIN, USER
}
